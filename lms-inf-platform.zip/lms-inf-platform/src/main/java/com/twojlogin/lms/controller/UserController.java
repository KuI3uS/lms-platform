package com.twojlogin.lms.controller;

import com.twojlogin.lms.entity.Submission;
import com.twojlogin.lms.repository.SubmissionRepository;
import com.twojlogin.lms.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import com.twojlogin.lms.entity.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {

    private final SubmissionRepository submissionRepository;
    private final UserRepository userRepository;
    public UserController(UserRepository userRepository, SubmissionRepository submissionRepository) {
        this.userRepository = userRepository;
        this.submissionRepository = submissionRepository;

    }
    @GetMapping("/class/{id}/users")
    public List<User> getUsersByClass(@PathVariable Long id) {
        return userRepository.findBySchoolClassId(id);
    }

    @GetMapping("/me")
    public UserDetails me() {
        return (UserDetails) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();
    }

    @GetMapping("/my-results")
    public List<Submission> myResults() {

        UserDetails userDetails = (UserDetails) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();

        User user = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        return submissionRepository.findByUserId(user.getId());
    }



    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin")
    public String admin() {
        return "ADMIN ONLY";
    }
}