import {
    BsCardText,
    BsLightbulb,
    BsExclamationTriangle,
    BsInfoCircle,
    BsCheckCircle,
    BsImage,
    BsCodeSlash,
    BsPlayBtn,
    BsQuestionCircle,
    BsDownload,
    BsQuote,
    BsDashLg
} from "react-icons/bs";

const BLOCK_TYPES = [
    {
        value: "TEXT",
        label: "Tekst",
        icon: <BsCardText />
    },
    {
        value: "TIP",
        label: "Wskazówka",
        icon: <BsLightbulb />
    },
    {
        value: "WARNING",
        label: "Ostrzeżenie",
        icon: <BsExclamationTriangle />
    },
    {
        value: "INFO",
        label: "Informacja",
        icon: <BsInfoCircle />
    },
    {
        value: "SUMMARY",
        label: "Podsumowanie",
        icon: <BsCheckCircle />
    },
    {
        value: "EXAMPLE",
        label: "Przykład kodu",
        icon: <BsCodeSlash />
    },
    {
        value: "IMAGE",
        label: "Obraz",
        icon: <BsImage />
    },
    {
        value: "VIDEO",
        label: "Film",
        icon: <BsPlayBtn />
    },
    {
        value: "TASK",
        label: "Zadanie",
        icon: <BsCodeSlash />
    },
    {
        value: "QUIZ",
        label: "Quiz",
        icon: <BsQuestionCircle />
    },
    {
        value: "DOWNLOAD",
        label: "Plik",
        icon: <BsDownload />
    },
    {
        value: "QUOTE",
        label: "Cytat",
        icon: <BsQuote />
    },
    {
        value: "DIVIDER",
        label: "Separator",
        icon: <BsDashLg />
    }
];

export default function BlockTypeSelector({
                                              value,
                                              onChange
                                          }) {

    return (

        <div>

            <h3 className="font-semibold text-white mb-4">

                Typ elementu

            </h3>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">

                {BLOCK_TYPES.map(type => (

                    <button
                        key={type.value}
                        type="button"
                        onClick={() => onChange(type.value)}
                        className={`
                            rounded-2xl
                            border
                            p-4
                            transition
                            flex
                            flex-col
                            items-center
                            gap-3

                            ${
                            value === type.value
                                ? "border-blue-500 bg-blue-600"
                                : "border-gray-700 bg-gray-800 hover:border-blue-500 hover:bg-gray-700"
                        }
                        `}
                    >

                        <div className="text-2xl">

                            {type.icon}

                        </div>

                        <span className="text-sm font-semibold">

                            {type.label}

                        </span>

                    </button>

                ))}

            </div>

        </div>

    );

}