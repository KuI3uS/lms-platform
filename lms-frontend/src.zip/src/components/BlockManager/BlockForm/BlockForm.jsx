import BlockTypeSelector from "./BlockTypeSelector";

import TextBlockForm from "./forms/TextBlockForm";
import ExampleBlockForm from "./forms/ExampleBlockForm";
import ImageBlockForm from "./forms/ImageBlockForm";
import VideoBlockForm from "./forms/VideoBlockForm";
import DownloadBlockForm from "./forms/DownloadBlockForm";
import QuoteBlockForm from "./forms/QuoteBlockForm";
import DividerBlockForm from "./forms/DividerBlockForm";
import TaskBlockForm from "./forms/TaskBlockForm";
import QuizBlockForm from "./forms/QuizBlockForm";

import BlockFooter from "./BlockFooter";

export default function BlockForm({
                                      block,
                                      setBlock,
                                      onSave,
                                      tasks
                                  }) {

    const type = block.type || "TEXT";

    return (

        <section className="bg-gray-900 border border-gray-800 rounded-3xl p-6 space-y-6">

            <div>

                <h2 className="text-2xl font-bold">

                    {block.id
                        ? "Edytuj element"
                        : "Dodaj element"}

                </h2>

                <p className="text-gray-400">

                    Dodaj kolejny element lekcji.

                </p>

            </div>

            <BlockTypeSelector
                value={type}
                onChange={(value)=>
                    setBlock(prev=>({
                        ...prev,
                        type:value
                    }))
                }
            />

            {(type !== "DIVIDER") && (

                <input
                    value={block.title || ""}
                    placeholder="Tytuł"
                    onChange={(e)=>
                        setBlock(prev=>({
                            ...prev,
                            title:e.target.value
                        }))
                    }
                    className="w-full bg-gray-800 border border-gray-700 rounded-xl p-3"
                />

            )}

            {type==="TEXT" && (
                <TextBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="TIP" && (
                <TextBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="WARNING" && (
                <TextBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="SUMMARY" && (
                <TextBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="INFO" && (
                <TextBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="EXAMPLE" && (
                <ExampleBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="IMAGE" && (
                <ImageBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="VIDEO" && (
                <VideoBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="DOWNLOAD" && (
                <DownloadBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="QUOTE" && (
                <QuoteBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="TASK" && (
                <TaskBlockForm
                    block={block}
                    setBlock={setBlock}
                    tasks={tasks}
                />
            )}

            {type==="QUIZ" && (
                <QuizBlockForm
                    block={block}
                    setBlock={setBlock}
                />
            )}

            {type==="DIVIDER" && (
                <DividerBlockForm/>
            )}

            <BlockFooter
                block={block}
                setBlock={setBlock}
                onSave={onSave}
            />

        </section>

    );

}